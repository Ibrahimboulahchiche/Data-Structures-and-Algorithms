package Maze;

import java.util.*;
import java.util.stream.Collectors;

public class Maze {

    /**
     * TODO
     * Returns the distance of the shortest path within the maze
     *
     * @param maze 2D table representing the maze
     * @return Distance of the shortest path within the maze, null if not solvable
     */
    public static Integer findShortestPath(ArrayList<ArrayList<Tile>> maze) {
        int numberOfLine = maze.size();
        if (numberOfLine == 0) return null;
        int numberOfColumn = maze.get(0).size();
        Coord coordinate = new Coord(0, 0);
        ArrayDeque<Coord> heap = new ArrayDeque<>();
        int[][] distanceTravelled = new int[numberOfLine][numberOfColumn];
        for (int i = 0; i < numberOfLine; i++) {
            for (int j = 0; j < numberOfColumn; j++) {
                distanceTravelled[i][j] = Integer.MAX_VALUE;
                if (maze.get(i).get(j).equals(Tile.Exit)) {
                    coordinate.i = i;
                    coordinate.j = j;
                }
            }
        }
        int i, j, smallestDistance;
        int[][] directions = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};
        distanceTravelled[coordinate.i][coordinate.j] = 0;
        heap.add(new Coord(coordinate.i, coordinate.j));
        while (!heap.isEmpty()) {
            coordinate = heap.poll();
            smallestDistance = distanceTravelled[coordinate.i][coordinate.j];
            for (int[] ints : directions) {
                i = coordinate.i + ints[0];
                j = coordinate.j + ints[1];
                if (i >= 0 && i < numberOfLine && j >= 0 && j < numberOfColumn
                        && distanceTravelled[i][j] == Integer.MAX_VALUE) {
                    if (maze.get(i).get(j).equals(Tile.Exit)) {
                        return smallestDistance + 1;
                    }
                    else if (maze.get(i).get(j).equals(Tile.Floor)) {
                        distanceTravelled[i][j] = smallestDistance + 1;
                        heap.add(new Coord(i, j));
                    }
                }
            }
        }
        return null;
    }

    public static class Coord {
        public int i;
        public int j;

        public Coord(int i, int j) {
            this.i = i;
            this.j = j;
        }

    }

    public static void printMaze(ArrayList<ArrayList<Tile>> maze) {
        for (ArrayList<Tile> row : maze) {
            System.out.println(row.stream().map(String::valueOf).collect(Collectors.joining("")));
        }
    }
}

