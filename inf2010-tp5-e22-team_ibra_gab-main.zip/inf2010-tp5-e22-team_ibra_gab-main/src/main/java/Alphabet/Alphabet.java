package Alphabet;
import java.util.ArrayList;
import java.util.Objects;

public class Alphabet {

    /**
     * TODO
     * From the words contained in the dictionary of a fictitious language, find the lexical order of
     * the symbols composing the language.
     *
     * @param dictionary Contains all the word of a language
     * @return The lexicalOrder of the symbols composing this language
     */
    public static ArrayList<Character> lexicalOrder(String[] dictionary) {
        ArrayList<Character> lexicalOrder = new ArrayList<>();
        Graph<Character> graph = new Graph<Character>();
        String theLastWord = "";
        for(String word : dictionary){
            if(!Objects.equals(theLastWord, "")){
                for(int i = 0; i < theLastWord.length() && i < word.length() ; i++){
                    if(theLastWord.charAt(i) != word.charAt(i)){
                        graph.connect(theLastWord.charAt(i), word.charAt(i));
                        break;
                    }
                }
            }
            theLastWord = word;
        }

        Vertex<Character> initialVertex = null;
        for(Vertex<Character> vertex : graph.vertices){
            if(vertex.indegree.equals(0)){
                initialVertex = vertex;
                break;
            }
        }
        Vertex<Character> current = initialVertex;
        while(current != null){
            lexicalOrder.add(current.label);
            Vertex<Character> next = null;
            for(Vertex<Character> vertex : current.toVertex){
                if(--vertex.indegree == 0){
                    next = vertex;
                }
            }
            current = next;
        }
        return lexicalOrder;
    }
}


