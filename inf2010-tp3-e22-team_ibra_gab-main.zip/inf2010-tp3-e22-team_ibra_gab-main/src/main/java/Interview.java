import java.util.LinkedList;
import java.util.List;
public class Interview {

    /** Expliquez votre complexité temporelle et spatiale en cas moyen et en pire cas à l'aide de commentaire dans le code
     *  Indiquez les équivalences telles que O(n + 1) => O(n) et O(2n) => O(n)
     *  La complexité spatiale au moyen et au pire cas est : O(1)
     *  La complexite temporelle au pire cas est: O(4+2n)=>O(n)
     *  La complexite temporelle au moyen cas est :O(n)
     *  Dans cette fonction il y a  des conditions if et des instructions de complexité O(1)
     *  Et une Boucle For qui a une complexité temporelle au pire cas de O(n)
     ** TODO Time Complexity : Worst Case O(n), explain Worst and Average Case
     ** TODO Space Complexity : Determine and Explain Worst and Average Case in comments
     ** TODO HAS TO BE ITERATIVE, , NOT RECURSIVE
     * @param numbers List of numbers sorted in ascending order containing 1 non-duplicate
     * @return non-duplicate number
     */
    public static Integer findNonDuplicateIterativeLinear(Integer[] numbers) {
        int sizeofContainer = numbers.length;
        for (int i = 0; i < sizeofContainer - 1; i += 2) {
            if (!numbers[i].equals(numbers[i + 1])) return numbers[i];
        }
        if (sizeofContainer % 2 == 1) return numbers[sizeofContainer - 1];
        return null;
    }
    /** Expliquez votre complexité temporelle et spatiale à l'aide de commentaire dans le code
     *  Indiquez les équivalences telles que O(n + 1) => O(n) et O(2n) => O(n)
     *  La complexité spatiale au moyen et au pire cas est : O(1) pour sizeOfContainer, minimumNumbers, highOfNumbers, centerOfNumbers et
     *  La valeur de retour de la fonction.
     *  La complexité temporelle au pire cas et a au moyen cas  est: O(log(n))
     ** TODO Time Complexity : Worst Case O(log(n)), explain Worst and Average Case
     ** TODO Space Complexity : Determine and Explain Worst and Average Case in comments
     ** TODO HAS TO BE ITERATIVE, NOT RECURSIVE
     * @param numbers List of numbers sorted in ascending order containing 1 duplicate
     * @return non-duplicate number
     */
    public static Integer findNonDuplicateIterative(Integer[] numbers) {
        int sizeOfContainer = numbers.length;
        int minimumNumbers = 0;
        int highOfNumbers = sizeOfContainer - 1;
        int centerOfNumbers = 0;
        while (minimumNumbers <= highOfNumbers) {
            centerOfNumbers = (highOfNumbers + minimumNumbers) / 2;
            if (minimumNumbers == highOfNumbers) return numbers[centerOfNumbers];
            if (centerOfNumbers % 2 != 0) {
                if (!numbers[centerOfNumbers].equals(numbers[centerOfNumbers - 1])) {
                    highOfNumbers = centerOfNumbers;
                } else {
                    minimumNumbers = centerOfNumbers + 1;
                }
            } else {
                if (!numbers[centerOfNumbers].equals(numbers[centerOfNumbers + 1])) {
                    highOfNumbers = centerOfNumbers;
                } else {
                    minimumNumbers = centerOfNumbers + 1;
                }
            }
        }
        return null;
    }

    /** Expliquez votre complexité temporelle et spatiale à l'aide de commentaire dans le code
     *  Indiquez les équivalences telles que O(n + 1) => O(n) et O(2n) => O(n)
     *  La complexité temporelle au pire et au moyen cas est de :O(log(n)
     *  La complexité spatiale au moyen et au pire cas est de : O(log(n))puisque on aura log(n) appels de
     *  la fonction récursive qui seront tous sauvegardés dans la pile d'appel.
     ** TODO Time Complexity : Worst Case O(log(n)), explain Worst and Average Case
     ** TODO Space Complexity : Determine and Explain Worst and Average Case in comments
     ** TODO HAS TO BE RECURSIVE, NOT ITERATIVE
     * @param numbers List of numbers sorted in ascending order containing 1 non-duplicate
     * @return non-duplicate number
     */
    public static Integer findNonDuplicateRecursive(Integer[] numbers) {
        int sizeOfContainer = numbers.length;
        return recursiveBinarySearch(numbers, 0, sizeOfContainer - 1);
    }
    public static Integer recursiveBinarySearch(Integer[] numbers, int minimumOfContainer, int highOfContainer){
        if (highOfContainer >= minimumOfContainer) {
            int centerOfContainer = (highOfContainer + minimumOfContainer) / 2;
            if (minimumOfContainer != highOfContainer) {
                if (centerOfContainer % 2 == 0) {
                    if (!numbers[centerOfContainer].equals(numbers[centerOfContainer + 1]))
                        return recursiveBinarySearch(numbers, minimumOfContainer, centerOfContainer);
                    else
                        return recursiveBinarySearch(numbers, centerOfContainer + 1, highOfContainer);
                } else {
                    if (numbers[centerOfContainer].equals(numbers[centerOfContainer - 1]))
                        return recursiveBinarySearch(numbers, centerOfContainer + 1, highOfContainer);
                    else
                        return recursiveBinarySearch(numbers, minimumOfContainer, centerOfContainer);
                }
            } else return numbers[centerOfContainer];
        }
        return null;
    }
}