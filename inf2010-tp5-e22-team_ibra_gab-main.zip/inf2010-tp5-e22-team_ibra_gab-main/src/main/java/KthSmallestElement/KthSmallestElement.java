package KthSmallestElement;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.*;
public class KthSmallestElement {
    /**
     * Explication de votre complexité temporelle
     * Time complexity : O ( k log max(m,n) )
     * Instanciation des structures de données, suivie de l'ajout de la première valeur de la matrice à nos structures de complexité (O(1)).
     * Par la suite, on arrive à une boucle while qui va itèrer k fois. À chacune des itérations,
     * il y a l'ajout de soit l'élément i+1, j, soit de l'élément i, j+1. Ce qui entraine qu'on traite deux éléments à la fois ce qui va
     * diviser le travail par 2. Donc, la complexité temporelle de l'ajout des éléments est de log(max(m,n)). Finalement, étant donnée qu'on
     * répète cet ajout d'éléments k fois, on a une complexité temporelle de O( k * log(max(m,n)).
     *
     * Explication de votre complexité spatiale
     * Space complexity : O ( max(m,n) )
     * Dans cette fonction, trois structures de données ont été utilisé. Tout d'abord, le HashSet qui permet de stocker seulement les valeurs uniques.
     * De ce fait, il n'y aura pas de répétitions de valeurs.Ensuite, le PriorityQueue qui permet de stocker les lignes de notre matrice et de retourner le plus petit élément
     * au sommet de notre queue.Finalement, une liste d'objet qui contient une ligne de notre matrice à la fois, qui a m objets et qui a une complexité spatiale de O(m).
     * D'autre part, la fonction poll est constamment appelé sur le PriorityQueue et on va extraire la ligne qu'on lui a ajouté dans l'itération qui précède ou
     * dans la première ligne. Ainsi, notre PriorityQueue ne peut pas contenir plus que les m éléments d'où sa complexité de O(m). Enfin, Le HashSet devrait avoir
     * tous les éléments de notre matrice. Par contre, étant donnée qu'on parcourt notre matrice de façon à trouver l'élément voulu avant que notre HashSet se remplisse,
     * notre complexié spatiale dépendra du nombres de lignes et de colonnes ce qui nous permet de conlure que sa complexité est de O(max(m,n)).
     * En résumé, notre complexité est de O(max(m,n) + m + m)ce qui équivaut à O(max(m,n).
     *
     */
    /** TODO Worst case
     *      Time complexity : O ( k log max(m,n) )
     *      Space complexity : O (max(m,n) )
     *
     * Returns the `k`th smallest element in `matrix`
     * @param matrix 2D table of shape M x N respecting the following rules
     *               matrix[i][j] <= matrix[i+1][j]
     *               matrix[i][j] <= matrix[i][j + 1]
     * @param k Index of the smallest element we want
     * @return `K`th smallest element in `matrix`, null if non-existent
     */
    static public <T extends Comparable<T>> T findKthSmallestElement(final T[][] matrix, final int k) {
        if (matrix == null || k < 0)
            return null;
        else {
            int kthTerm = k + 1;
            HashSet<List<Object>> valuesMeeted = new HashSet<>();
            PriorityQueue<List<Object>> availableRows;
            availableRows = new PriorityQueue<>(Comparator.comparing(value -> (T) value.get(0)));

            valuesMeeted.add(Arrays.asList(matrix[0][0], 0, 0));
            availableRows.add(Arrays.asList(matrix[0][0], 0, 0));
            while (availableRows.size() > 0) {
                kthTerm--;
                List<Object> line = availableRows.poll();
                if (matrix[(Integer) line.get(1)].length - 1 > (Integer) line.get(2))
                    addNewValue(availableRows,valuesMeeted,Arrays.asList(matrix[(Integer) line.get(1)][(Integer) line.
                            get(2) + 1], line.get(1), (Integer) line.get(2) + 1));
                if (matrix.length - 1 > (Integer) line.get(1))
                    addNewValue(availableRows,valuesMeeted,Arrays.asList(matrix[(Integer) line.get(1) + 1][(Integer) line
                            .get(2)], (Integer) line.get(1) + 1, line.get(2)));
                if (kthTerm == 0)
                    return (T) line.get(0);
            }
        }
        return null;
    }

    static void addNewValue(PriorityQueue<List<Object>> availableRows, HashSet<List<Object>> valuesMeeted, List<Object> values){
        if (!valuesMeeted.contains(values)){
            valuesMeeted.add(values);
            availableRows.add(values);
        }
    }
}