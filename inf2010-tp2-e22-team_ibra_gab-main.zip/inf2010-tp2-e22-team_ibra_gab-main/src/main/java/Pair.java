public class Pair {
    String first;
    Integer second;

    public Pair(String first, Integer second) {
        this.first = first;
        this.second = second;
    }
}
