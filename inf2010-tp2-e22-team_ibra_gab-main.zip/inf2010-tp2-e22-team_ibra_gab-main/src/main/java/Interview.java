import java.util.*;
import java.util.HashMap;

public final class Interview {

    /**
     * Expliquez votre complexité temporelle et spatiale à l'aide de commentaire dans le code
     * n représente le nombre de charactère de `phrase` et m le nombre de charactère de `stopwords`
     * Indiquez les équivalences telles que O(n + 1 + m + 1) => O(n+m) et O(2n+3m) => O(n+m) lorsque possible
     * <p>
     * * TODO Justify Time Complexity  : Average Case O(n+m)
     *   La fonction findMostCommonValidWord utilise une première structure If qui se fait en O(1(...)). Ensuite, deux fonctions,
     *   soient toLowerCase() et split() se font les deux en O(n), et ne sont pas imbriquées, donc O(1(n + n)) = O(n).
     *   Ensuite  une boucle for se fait et on y utilise la méthode constainsKey() qui se fait
     *   en O(1), donc O(n(1)) = O(n). Juste en dessous, on itrère sur stopwords, donc O(n + m), et on appelle remove() sur
     *   la hashmap qui se fait en O(1), donc O(n+m+1) = O(n + m). Le deuxième bloc prend une structure if-else-, et à l'intérieur
     *   on itère sur les valeurs de notre hashmap, donc O(n + m + 1(n(...))), avec un if-else imbriqué qui se fait en O(1), donc on
     *   fini avec O(n + m + 1(n(1))) = O(n + m) de complexité temporelle.
     *
     * * TODO Justify Space Complexity : Worst Case O(n+m)
     *   La première structure qu'on crée est la hashmap et on la remplie en itérant sur une array, donc dans le pire des cas
     *   on arrive à 2*N, donc O(n + (...)). En sachant qu'on joue aussi avec le tableau stopwords, et que celui-ci possède m éléments,
     *   on parvient à O(n + m). On initialise un paire et on la retourne, et ces deux opérations prennent O(1), donc O(n + m + 1 + 1), donc
     *   on finis avec une complexité temporelle de O(n + m).
     *
     * @param phrase    String containing a sequence of words separated by a space
     * @param stopwords String array containing all the stop words
     * @return Pair containing two elements, first being the most common word not in the stop words,
     * second being the number of occurences of this word
     */
    public static Pair findMostCommonValidWord(String phrase, String[] stopwords) { // Space: n + m
        HashMap<String, Pair> numberWords = new HashMap<>();// Temporel: 1  Space: 1
        if (phrase.length() != 0) { // Temporel: 1
            phrase = phrase.toLowerCase(Locale.ROOT); // Temporel: n  Space: n - n
            String[] myWords = phrase.split(" "); // Temporel: n  Space: n
            for (String word : myWords) { // Temporel: n
                if (!numberWords.containsKey(word)) {
                    numberWords.put(word, new Pair(word, 1));
                } else {
                    numberWords.get(word).second++; // Temporel: 1
                }
            }
            // Temporel: Pour la boucle for suivante O(m * 1) => O(m)
            for (String word : stopwords) { // Temporel: m
                numberWords.remove(word.toLowerCase(Locale.ROOT)); // Temporel: 1
            }
        }
        Pair mostCommon = new Pair("", 0); // Temporel: 1  Space: 1
        if (!numberWords.isEmpty()) { // Temporel: 1
            for (Pair word : numberWords.values()) { // Temporel: n
                if (word.second > mostCommon.second) { // Temporel: 1
                    mostCommon = word; // Temporel : 1  Space: 1 - 1 (désassigne et réassigne par la suite)
                }
                else if (word.second.equals(mostCommon.second) && word.first.charAt(0)< mostCommon.first.charAt(0)) {//Temporel:1
                    mostCommon=word; //Temporel : 1  Space: 1 - 1 (désassigne et réassigne par la suite)
                }
            }
        } else {
            mostCommon = new Pair(null, null); // Temporel: 1  Space: 1 - 1 (désassigne et réassigne par la suite)
        }
        return mostCommon; // Temporel: 1
    }
}