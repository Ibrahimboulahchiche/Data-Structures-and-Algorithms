import java.util.*;

public final class Interview {
    /**
     * Expliquez votre complexité temporelle et spatiale à l'aide de commentaire dans le code
     * Indiquez les équivalences telles que O(n + 1) => O(n) et O(2n) => O(n)
     *
     * * TODO Time Complexity  :
     * * TODO Space Complexity :
     *
     * @param boxes The array that contains the weight of each box.
     * @return The weight of the final box if it is applicable.
     */
    static public int lastBox(int[] boxes) {
        PriorityQueue<Integer> myHeap = new PriorityQueue<>(Comparator.reverseOrder());

        //Notre boucle for doit parcourir n éléments et effectuer une opération d'ajout(add) dans notre PriorityQueue
        // myHeap qui a une complexité est de O(log n).
        //De ce fait, on aura une complexité temporelle et spatiale de O(n * log (n)) soit O(nlog(n)).
        for (int i : boxes)
        {
            myHeap.add(i);
        }

        //Nous avons n opérations pour parcourir notre PriorityQueue myHeap
        // Donc la complexité => O(n)
        while (!myHeap.isEmpty())
        {
            //L'opération de comparaison pour la condition du if a une complexité => O(1)
            if (myHeap.size() != 1) {
                //Notre méthode poll que nous avons utilisé a une complexité temporelle de O(log(n)) ce qui permet de
                // statuer sur la complexité de l'initialisation de FirstElement et secondToFirstElement:
                // notre complexité temporelle nous donne: O(log(n) + log(n)) = O(2 * log(n)) = O(log(n))
                //et notre complexité spatiale => O(4 * 2 * log(n)) = O(8 * log(n)) = O(log(n))
                int FirstElement = myHeap.poll();
                int secondToFirstElement = myHeap.poll() ;

                //L'opération de comparaison pour la condition du deuxième if a une complexité => O(1)
                if (FirstElement != secondToFirstElement)
                {
                    //L'ajout, dans le PriorityQueue myHeap, avec la méthode add nous donne une
                    // complexité temporelle => O(log(n))
                    // et une complexité spatiale => O( 4 * log(n)) => O(log(n))
                    myHeap.add(FirstElement - secondToFirstElement);
                }
                //En résumé, notre boucle while, une fois qu'elle arrive à la fin du premier if a une complexité temporelle de :
                // O(n * (1 * log(n) + 1 * log(n))) = O(n * (2 * log(n))) = O(2 * n * log(n)) = O(nlog(n))
                //Et une complexité spatiale:
                // O(n * (1 * log(n) + 1*log(n))) = O(2nlog(n)) = O(nlog(n))
            }
            else
            {
                //Dans notre return effectue, on utilise une opération avec un poll
                // ce qui donne une complexité temporelle et spatiale de O(log(n))

                //Finalement, arrivé à la fin de notre else, notre boucle While aura une complexité temporelle et spatiale de
                // O(n*log(n)) = O(nlog(n))
                return myHeap.poll();
            }
        }
        return 0;
    }
    //De ce fait, lastBox a comme complexité temporelle:O(nlog(n) + nlog(n)) = O(nlog(n)) et
    //comme complexité spatiale : O(nlog(n) + nlog(n)) = O(nlog(n))

}
