import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import static java.lang.Math.max;


public class AvlTree<ValueType extends Comparable<? super ValueType> > {

    // Only node which has its parent to null
    private BinaryNode<ValueType> root;

    public AvlTree() { }
    //ideas
    /*https://www.javatpoint.com/avl-tree-program-in-java*/
    /** TODO Worst case : O ( log n ) HAS TO BE ITERATIVE, NOT RECURSIVE
     *  TODO: What's the average case? Briefly explain
     *  Pour ajouter une node, il faut comparer les valeurs en traversant l'arbre de haut en bas, se qui se fait en O(log(n)).
     *  Selon la situation de la balance de l'arbre, il faut utiliser balance(). Mais dans tous les cas, ceci se fait à la fin,
     *  et donc on parvient à une complexité moyenne de O(log(n)).
     *
     * Adds value to the tree and keeps it as a balanced AVL Tree
     * Should call balance only if insertion succeeds
     * AVL Trees do not contain duplicates
     *
     * @param value value to add to the tree
     */
    public void add(ValueType value) {
        if(contains(value))
            return;

        BinaryNode<ValueType> temporaryNode = root;
        BinaryNode<ValueType> parent = null;

        if(temporaryNode == null){
            root = new BinaryNode<ValueType>(value, null);
            return;
        }

        while(temporaryNode != null){
            parent = temporaryNode;
            temporaryNode = temporaryNode.value.compareTo(value) > 0 ? temporaryNode.left : temporaryNode.right;
        }
        temporaryNode = new BinaryNode<ValueType>(value, parent);

        if(parent.value.compareTo(temporaryNode.value) > 0){
            parent.left = temporaryNode;
        }else{
            parent.right = temporaryNode;
        }
        BinaryNode<ValueType> nodeToInsert = temporaryNode;
        while(temporaryNode.parent != null){
            if(temporaryNode.parent.height < temporaryNode.height + 1)
                temporaryNode.parent.height = temporaryNode.height + 1;
            temporaryNode = temporaryNode.parent;
        }
        balance(nodeToInsert);

    }

    /** TODO Worst case : O ( log n )
     *  TODO: What's the average case? Briefly explain
     *  Pour enlever une valeur, il faut parcourir l'arbre pour atteindre la node, donc on est en O(log(n)). Selon la situation,
     *  il peut être nécessaire de balancer ou pas, mais ceci se fait à la fin de tout, donc on reste en O(log(n)).
     *
     * Removes value from the tree and keeps it as a balanced AVL Tree
     * Should call balance only if removal succeeds
     *
     * @param value value to remove from the tree
     */
    public void remove(ValueType value) {
        if(!contains(value))
            return;

        BinaryNode<ValueType> temporaryNode = root;

        while(!temporaryNode.value.equals(value)) {
            temporaryNode = temporaryNode.value.compareTo(value) > 0 ? temporaryNode.left : temporaryNode.right;
        }
        if(temporaryNode.right == temporaryNode.left){
            if(temporaryNode.value.equals(root.value))
                root = null;
            else if(temporaryNode.parent.value.compareTo(temporaryNode.value) > 0){
                temporaryNode.parent.left = null;
            }else{
                temporaryNode.parent.right = null;
            }
        }
        else if(temporaryNode.right == null || temporaryNode.left == null){
            BinaryNode<ValueType> child = temporaryNode.right == null ? temporaryNode.left : temporaryNode.right;
            if(temporaryNode.value.equals(root.value))
                root = child;
            else if(temporaryNode.parent.value.compareTo(temporaryNode.value) > 0){
                temporaryNode.parent.left = child;
            }else{
                temporaryNode.parent.right = child;
            }
        }
        else{
            BinaryNode<ValueType> min = temporaryNode.right;

            while(min.left != null)
                min = min.left;

            temporaryNode.value = min.value;
            min.parent.left = min.right;
            if(min.right != null)
                min.right.parent = min.parent;
        }
        BinaryNode<ValueType> nodeToRemove = temporaryNode;

        temporaryNode = temporaryNode.parent;
        while(temporaryNode != null){
            int lHeight = temporaryNode.left == null ? -1 : temporaryNode.left.height;
            int rHeight = temporaryNode.right == null ? -1 : temporaryNode.right.height;
            temporaryNode.height = max(lHeight,rHeight) + 1;
            temporaryNode = temporaryNode.parent;
        }

        balance(nodeToRemove);

    }


    /** TODO Worst case : O ( log n ) HAS TO BE ITERATIVE, NOT RECURSIVE
     *  TODO: What's the average case? Briefly explain
     *  On traverse l'arbre de node en node par la boucle while(node != null), donc O(log(n)), et puisqu'on
     *  fait des assignations pour aller à la prochaine node, en passant par des conditions, on arrive à
     *  O(log(n) (1 + 1+ 1)) = O(log(n)) en général.
     *
     * Verifies if the tree contains value
     * @param value value to verify
     * @return if value already exists in the tree
     */
    public boolean contains(ValueType value) {
        BinaryNode<ValueType> temporaryNode = root;

        while(temporaryNode != null){
            if(temporaryNode.value.equals(value))
                return true;
            temporaryNode = temporaryNode.value.compareTo(value) > 0 ? temporaryNode.left : temporaryNode.right;
        }
        return false;

    }

    /** TODO Worst case : O( 1 )
     *  TODO: What's the average case? Briefly explain
     *  Étant donné que le pire des cas est en O(1), et que c'est le cas le plus rapide est en O(1),
     *  on est en général en O(1).
     *
     * Returns the max level contained in our root tree
     * @return Max level contained in our root tree
     */
    public int getHeight() {
        return root == null ? -1 : root.height;
    }

    /** TODO O( log n ) HAS TO BE ITERATIVE, NOT RECURSIVE
     *  TODO: What's the average case? Briefly explain
     *  Étant donné que pour trouver une valeur spécifique dans l'arbre, on doit le traverser, les opérations
     *  de traverses se font en général en O(log(n)).
     *
     * Returns the node which has the minimal value contained in our root tree
     * @return Node which has the minimal value contained in our root tree
     */
    public ValueType findMin() {
        ValueType lowestValue;
        if(root==null)
            return null;
        else{
            lowestValue = root.value;
            BinaryNode<ValueType> index = root;
            while(index!=null){
                lowestValue = index.value;
                index = index.left;
            }
        }
        return lowestValue;
    }

    /** TODO O( log n ) HAS TO BE ITERATIVE, NOT RECURSIVE
     *  TODO: What's the average case? Briefly explain
     *  Étant donné que pour trouver une valeur spécifique dans l'arbre, on doit le traverser, les opérations
     *  de traverses se font en général en O(log(n)).
     *
     * Returns the node which has the maximum value contained in our root tree
     * @return Node which has the maximum value contained in our root tree
     */
    public ValueType findMax() {

        if (root == null) return null;
        else{
            while (root.right != null){
                root = root.right;
            }
        }
        return root.value;
    }

    /** TODO Worst case : O( n ) HAS TO BE ITERATIVE, NOT RECURSIVE
     *  TODO: What's the average case? Briefly explain
     *  La méthode utilise une traversée d'arbre, qui se fait en O(log(n)). Étant donné qu'on rempli une liste avec
     *  chaque lecture, l'insertion se fait en O(n), et ce dernier domine sur O(log(n)), donc on est en O(n).
     *
     * Returns all values contained in the root tree in ascending order
     * @return Values contained in the root tree in ascending order
     */
    public List<ValueType> infixOrder() {
        if ( root == null )
        {
            return null;
        }
        else {
            List<ValueType> myListOfNodes = new ArrayList<ValueType>();
            BinaryNode<ValueType> node = root;
            Stack<BinaryNode> myStackOfNodes = new Stack<BinaryNode>();

            while (node != null | !myStackOfNodes.isEmpty())
            {
                while (node != null)
                {
                    myStackOfNodes.push(node);
                    node = node.left;
                }

                node = myStackOfNodes.pop();
                myListOfNodes.add(node.value);
                node = node.right;
            }
            return myListOfNodes;
        }

    }

    /** TODO Worst case : O( log n ) HAS TO BE ITERATIVE, NOT RECURSIVE
     *  TODO: What's the average case? Briefly explain
     *  Pour balancer, il faut parcourir la node précise, qui se trouve dans l'arbre, donc c'est en O(log(n)).
     *  Puisque ça utilise les méthode d'hauteur, qui sont en O(1), et qu'il y a différentes affections et conditions
     *  qui ne change pas puisqu'elles sont en O(1), on est en O(log(n)).
     *
     * Balances the whole tree
     * @param node Node to balance all the way to root
     */
    private void balance(BinaryNode<ValueType> node) {
        while(node!=null) {
            AvlTree<ValueType> leftPart = new AvlTree<>();
            leftPart.root = node.left;
            AvlTree<ValueType> right = new AvlTree<>();
            right.root = node.right;
            if ((leftPart.getHeight() - right.getHeight()) > 1) {
                AvlTree<ValueType> leftLeftTree = new AvlTree<>();
                leftLeftTree.root = node.left.left;
                AvlTree<ValueType> leftRightTree = new AvlTree<>();
                leftRightTree.root = node.left.right;
                if (leftLeftTree.getHeight() < leftRightTree.getHeight())
                    rotateRight(node.left);
                rotateLeft(node);
            }
            else if ((right.getHeight() - leftPart.getHeight()) > 1) {
                AvlTree<ValueType> rightLeftTree = new AvlTree<>();
                rightLeftTree.root = node.right.left;
                AvlTree<ValueType> rightRightTree = new AvlTree<>();
                rightRightTree.root = node.right.right;
                if (rightRightTree.getHeight() < rightLeftTree.getHeight())
                    rotateLeft(node.right);
                rotateRight(node);
            }
            node = node.parent;
        }
    }

    /** TODO Worst case : O ( 1 )
     *
     * Single rotation to the left child, AVR Algorithm
     * @param node1 Node to become child of its left child
     */
    private void rotateLeft(BinaryNode<ValueType> node1){
        BinaryNode<ValueType> parent = node1.parent;
        BinaryNode<ValueType> temporaryNode = node1.left;
        node1.left = temporaryNode.right;
        temporaryNode.right = node1;
        temporaryNode.parent = node1.parent;
        node1.parent = temporaryNode;
        temporaryNode.right.height = max(BinaryNode.getHeight(temporaryNode.right.left),
                BinaryNode.getHeight(temporaryNode.right.right))+1;
        temporaryNode.height = max(BinaryNode.getHeight(temporaryNode.left),
                BinaryNode.getHeight(temporaryNode.right))+1;
        if (temporaryNode.right.left!=null)
            temporaryNode.right.left.parent = temporaryNode.right;
        if (node1.equals(root))
            root=temporaryNode;
        else if( parent.value.compareTo(node1.value)>0)
            parent.left=temporaryNode;
        else
            parent.right=temporaryNode;
    }

    /** TODO Worst case : O ( 1 )
     *
     * Single rotation to the right, AVR Algorithm
     * @param node1 Node to become child of its right child
     */
    private void rotateRight(BinaryNode<ValueType> node1){
        BinaryNode<ValueType> parent=node1.parent;
        BinaryNode<ValueType> node=node1.right;
        node1.right=node.left;
        node.left=node1;
        node.parent=node1.parent;
        node.left.parent= node;
        node.left.height = max(BinaryNode.getHeight(node.left.left),
                BinaryNode.getHeight(node.left.right))+1;
        node.height = max(BinaryNode.getHeight(node.left),
                BinaryNode.getHeight(node.right))+1;
        if (node.left.right!=null)
            node.left.right.parent=node.left;
        if (node1.equals(root))
            root=node;
        else if(parent.value.compareTo(node1.value)>0)
            parent.left=node;
        else
            parent.right=node;
    }

    /** TODO O( n )
     *  TODO: What's the average case? Briefly explain
     *  Tout comme sa version itérative, chaque insertion dans la liste vaut O(n), et ceci domine sur le temps en
     *  O(log(n)) du parcour de l'arbre, donc le temps est en O(n).
     *
     * Builds items which should contain all values within the root tree in ascending order
     * @param currentNode Node currently being accessed in this recursive method
     * @param items List being modified to contain all values in the root tree in ascending order
     */
    //à faire
    private void infixOrder(BinaryNode<ValueType> currentNode, List<ValueType> items){
        if (currentNode == null ) return ;
        else if (currentNode == root ) items.add(root.value);
        else {
            infixOrder(currentNode.left , items ) ;
            items.add(currentNode.value);
            infixOrder(currentNode.right , items );
        }

    }

    static private class BinaryNode<ValueType> {
        ValueType value;

        BinaryNode<ValueType> parent; // Pointer to the node containing this node

        BinaryNode<ValueType> left = null; // Pointer to the node on the left which should contain a value below this.value
        BinaryNode<ValueType> right = null; // Pointer to the node on the right which should contain a value above this.value

        int height = 0;

        // Null-safe height accessor
        // Raw use of parameterized class is justified because we do not use any value of the BinaryNode, only the height of the parameter
        static public int getHeight(BinaryNode node) {
            return node != null ? node.height : -1;
        }

        BinaryNode(ValueType value, BinaryNode<ValueType> parent)
        {
            this.value = value;
            this.parent = parent;
        }
    }
}